package com.example.currency_exchange_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
